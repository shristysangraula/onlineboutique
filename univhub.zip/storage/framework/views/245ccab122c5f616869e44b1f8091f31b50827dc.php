<?php $__env->startSection('content'); ?>
    <br>
<div class="row">
    <div class="small-6 small-centered columns">
        <h3>Shipping Info</h3>

        <?php echo Form::open(['route' => 'address.store', 'method' => 'post']); ?>


        <div class="form-group">
            <?php echo e(Form::label('addressline1', 'Address Line 1')); ?>

            <?php echo e(Form::text('addressline1', null, array('class' => 'form-control'))); ?>

        </div>

        <div class="form-group">
            <?php echo e(Form::label('addressline2', 'Address line 2')); ?>

            <?php echo e(Form::text('addressline2', null, array('class' => 'form-control'))); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('email', 'Email')); ?>

            <?php echo e(Form::text('email', null, array('class' => 'form-control'))); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('full_name', 'Full Name')); ?>

            <?php echo e(Form::text('full_name', null, array('class' => 'form-control'))); ?>

        </div>
        
        <div class="form-group">
            <?php echo e(Form::label('phone', 'Phone')); ?>

            <?php echo e(Form::text('phone', null, array('class' => 'form-control'))); ?>

        </div>

        <?php echo e(Form::submit('Proceed to Payment', array('class' => 'button success'))); ?>

        <?php echo Form::close(); ?>

    </div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>