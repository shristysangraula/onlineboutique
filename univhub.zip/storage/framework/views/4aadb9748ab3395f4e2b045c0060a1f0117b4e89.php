<?php $__env->startSection('title','apparel'); ?>

<?php $__env->startSection('content'); ?>

    <!-- products listing -->
    <!-- Latest apparels -->

                    <?php echo e($product->name); ?>

                    
                    
                    <?php echo e($product->size); ?>

                    </div>
                    
    <div class="row">
        <div class="small-5 small-offset-1 columns">
            <div class="item-wrapper">
                <div class="img-wrapper">
                     <img src="<?php echo e(url('images',$product->image)); ?>"/>
                </div>
            </div>
        </div>
        
        <div class="small-6 columns">
            <div class="item-wrapper">
                <h3 class="subheader">
                    <span class="price-tag"><?php echo e($product->price); ?></span> <?php echo e($product->name); ?>


            <?php echo e($product->description); ?>

                </h3>
                <div class="row">
                    <div class="large-12 columns">
                        <label>
                            Select Size
                            <select >
                                <option value="small">
                                    Small
                                </option>
                                <option value="medium">
                                    Medium
                                </option>
                                <option value="large">
                                    Large
                                </option>

                            </select>
                        </label>
                        <a href=" <a href = "<?php echo e(route('cart.addItem', $product->id)); ?>" class="button  expanded">Add to Cart</a>
                    </div>
                </div>
                <p class="text-left subheader">
                    <small>* Designed by <a href="https://www.youtube.com/webdevmatics">Webdevmatics</a></small>
                </p>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>