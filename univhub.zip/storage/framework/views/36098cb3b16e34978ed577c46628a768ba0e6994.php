<table border = "2">
    <tr>
   <td>ID</td>
   <td>Name</td>
<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    </tr>
    <tr>
    <td><?php echo e($products->id); ?></td>
    <td><?php echo e($products->name); ?></td>
    
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>  
</table>