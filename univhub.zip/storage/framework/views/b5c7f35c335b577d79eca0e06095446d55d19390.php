<?php $__env->startSection('title','apparel'); ?>

<?php $__env->startSection('content'); ?>

    <!-- products listing -->
    <!-- Latest apparels -->

                
                    
    <div class="row">
        <div class="small-5 small-offset-1 columns">
            <div class="item-wrapper">
                <div class="img-wrapper">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                     <img src="<?php echo e(url('images',$product->image)); ?>"/>
                </div>
            </div>
        </div>
        
        <div class="small-6 columns">
            <div class="item-wrapper">
                <h3 class="subheader">
                    
                    <span class="price-tag"><?php echo e($product->name); ?></span> 

            
                </h3>
                <div class="row">
                    <div class="large-12 columns">
                        <h3><?php echo e($product->price); ?></h3></br>
                        <h3>Description:</h3><?php echo e($product->description); ?>

                        
                     <a href = "<?php echo e(route('cart.addItem', $product->id)); ?>" class="button  expanded">Add to Cart</a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>