<?php $__env->startSection('title','apparels'); ?>
<?php $__env->startSection('content'); ?>
    <!-- products listing -->
    <!-- Latest apparels -->
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $apparels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apparel): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
            <div class="small-3 medium-3 large-3 columns">
                <div class="item-wrapper">
                    <div class="img-wrapper">
                        <a href="<?php echo e(route('cart.addItem',$apparel->id)); ?>" class="button expanded add-to-cart">
                            Add to Cart
                        </a>
                        <a href="<?php echo e(route('productdetail',$apparel->id)); ?>">
                            <img src="<?php echo e(url('images',$apparel->image)); ?>"/>
                        </a>
                    </div>
                    <a href="<?php echo e(route('apparel')); ?>">
                        <h3>
                            <?php echo e($apparel->name); ?>

                        </h3>
                    </a>
                    <h5>
                        Rs.<?php echo e($apparel->price); ?>


                    </h5>
                    <p>
                        <?php echo e($apparel->description); ?>

                    </p>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
        <h3>No apparels</h3>
       <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>